#include <stdio.h>

void transpose(int mat[][100], int row, int col) {
    int transposeMat[col][row];

    // Computing transpose
    for (int i = 0; i < col; i++) {
        for (int j = 0; j < row; j++) {
            transposeMat[i][j] = mat[j][i];
        }
    }

    // Printing transpose matrix
    for (int i = 0; i < col; i++) {
        for (int j = 0; j < row; j++) {
            printf("%d ", transposeMat[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int matrix[100][100];
    int row, col;

    // Input matrix dimensions
    scanf("%d", &row);
    col = row; // Assuming it's a square matrix

    // Input matrix elements
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    // Function call to compute and print transpose
    transpose(matrix, row, col);

    return 0;
}
